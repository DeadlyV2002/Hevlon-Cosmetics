# HO Inventory + Sales Control Center

Vercel-ready React/Vite + Supabase starter for the four-layer hierarchy:
HO Admin → State/Super Distributor → Distributor → Retailer, plus salesman field performance and collections.

## Included
- Modern responsive HO dashboard
- Inventory truth monitor: expected vs reported vs verified stock
- Stock difference / unexplained stock exceptions
- Tally / distributor / secondary-sales import screen for Excel/CSV
- Reconciliation center
- Collections and overdue tracking
- Salesman roster and performance slots (15–20+ per region)
- Calls, productive calls, PC%, secondary sales, Sec/PC and collections KPIs
- Exception center and report cards
- Supabase schema with permanent ledger tables, audit trail, RLS bootstrap policies
- Vercel SPA rewrite and environment example

## Setup
1. Create a Supabase project.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. Copy `.env.example` to `.env.local` and set `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY`.
4. Run `npm install` then `npm run build`.
5. Deploy this folder to Vercel. Add the same two VITE variables under Vercel Project → Settings → Environment Variables and redeploy.

Supabase's current React quickstart uses Vite, `@supabase/supabase-js`, `VITE_SUPABASE_URL`, and `VITE_SUPABASE_PUBLISHABLE_KEY`; production RLS policies should be reviewed and tightened for your organization hierarchy.

## Important production note
The UI is fully wired as a deployable starter and the database schema is ready for the next integration step. PDF extraction, authenticated role-to-hierarchy RLS, and automated server-side reconciliation jobs should be enabled before production use with real financial/inventory data. The browser import currently parses Excel/CSV and demonstrates standardization; it does not pretend a PDF has been verified when it has not.


## PDF extraction
The Bill Import module accepts PDF bills and extracts text page-by-page with PDF.js in the browser. It reports page count, extracted text lines, and bill-related lines before reconciliation. Text PDFs are supported directly. Scanned/image-only PDFs are not silently imported; they should be routed through OCR before posting transactions.
